CREATE SCHEMA "public";
CREATE SCHEMA "sqids";
CREATE TYPE "user_status" AS ENUM('UNKNOWN', 'PENDING', 'VERIFIED', 'ACTIVE', 'INACTIVE');
CREATE TYPE "artist_status" AS ENUM('UNKNOWN', 'PENDING', 'ACTIVE', 'INACTIVE');
CREATE TYPE "release_status" AS ENUM('UNKNOWN', 'REVIEW', 'PRE_ORDER', 'PENDING', 'ACTIVE', 'PAUSED', 'ACCEPTED');
CREATE TYPE "release_type" AS ENUM('UNKNOWN', 'ALBUM', 'SINGLE', 'EP', 'VIDEO');
CREATE TYPE "recording_type" AS ENUM('AUDIO', 'VIDEO', 'UNKNOWN');
CREATE TYPE "collectible_status" AS ENUM('UNKNOWN', 'PENDING', 'ACTIVE');
CREATE TABLE "artist" (
	"id" bigserial PRIMARY KEY,
	"apple_id" bigint,
	"description" varchar DEFAULT '' NOT NULL,
	"cover" varchar DEFAULT '' NOT NULL,
	"icon" varchar DEFAULT '' NOT NULL,
	"name" varchar DEFAULT '' NOT NULL,
	"status" artist_status DEFAULT 'UNKNOWN' NOT NULL
);
CREATE TABLE "artist_recording" (
	"recording_id" bigint NOT NULL,
	"artist_id" bigint NOT NULL
);
CREATE TABLE "artist_release" (
	"artist_id" bigint NOT NULL,
	"release_id" uuid NOT NULL,
	"index" smallint NOT NULL
);
CREATE TABLE "collectible" (
	"id" bigserial PRIMARY KEY,
	"release_id" uuid NOT NULL,
	"user_id" bigint NOT NULL,
	"index" smallint NOT NULL,
	"status" collectible_status DEFAULT 'UNKNOWN' NOT NULL,
	"created_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
	"updated_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);
CREATE TABLE "collectible_history" (
	"collectible_id" bigint UNIQUE,
	"index" smallint UNIQUE,
	"user_id" bigint,
	"created_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
	CONSTRAINT "collectible_provenance_unique" UNIQUE("collectible_id","index")
);
CREATE TABLE "collectible_transaction" (
	"id" bigserial PRIMARY KEY,
	"payment_id" varchar CONSTRAINT "collectible_transaction_payment_id_key" UNIQUE,
	"user_id" bigint NOT NULL,
	"release_id" uuid NOT NULL,
	"payment_status" varchar(50) NOT NULL,
	"amount_cents" integer NOT NULL,
	"quantity" integer NOT NULL,
	"total_amount_cents" integer NOT NULL,
	"currency" char(3) DEFAULT 'USD' NOT NULL,
	"created_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
	"updated_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);
CREATE TABLE "collectible_transaction_collectible" (
	"collectible_transaction_id" bigint NOT NULL,
	"collectible_id" bigint NOT NULL
);
CREATE TABLE "dynamo_sales_deprecated" (
	"id" serial,
	"album_id" text,
	"album_name" text,
	"album_index" integer,
	"album_price" integer,
	"first_name" text,
	"last_name" text,
	"email" text,
	"processed" boolean DEFAULT false NOT NULL,
	"release_id" uuid,
	"user_id" bigint
);
CREATE TABLE "recording" (
	"id" bigserial PRIMARY KEY,
	"release_id" uuid NOT NULL,
	"type" recording_type DEFAULT 'UNKNOWN' NOT NULL,
	"title" varchar NOT NULL,
	"index" smallint NOT NULL,
	"duration" integer NOT NULL,
	"source_url" varchar DEFAULT '' NOT NULL,
	"source_preview_url" varchar DEFAULT '' NOT NULL,
	"stream_id" varchar DEFAULT '' NOT NULL,
	"stream_preview_id" varchar DEFAULT '' NOT NULL
);
CREATE TABLE "release" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid(),
	"cover" varchar DEFAULT '' NOT NULL,
	"duration" integer DEFAULT 0 NOT NULL,
	"title" varchar DEFAULT '' NOT NULL,
	"description" varchar DEFAULT '' NOT NULL,
	"genre" varchar DEFAULT '' NOT NULL,
	"embed" varchar DEFAULT '' NOT NULL,
	"isrc" varchar DEFAULT '' NOT NULL,
	"released_at" timestamp with time zone,
	"type" release_type DEFAULT 'UNKNOWN' NOT NULL,
	"quantity" integer DEFAULT 0 NOT NULL,
	"price" integer DEFAULT 0 NOT NULL,
	"currency" char(3) DEFAULT 'USD' NOT NULL,
	"sold" integer DEFAULT 0 NOT NULL,
	"tracks" integer DEFAULT 0 NOT NULL,
	"status" release_status DEFAULT 'UNKNOWN' NOT NULL,
	"bundle_desc" text,
	"physical" boolean DEFAULT false NOT NULL,
	"shipping_rate" text DEFAULT '' NOT NULL,
	"bundle_image" text,
	"unlisted" boolean DEFAULT false NOT NULL,
	"bundle_header" text,
	"bundle_footer" text,
	"hide_quantity" boolean
);
CREATE TABLE "schema_migrations" (
	"version" varchar(255) PRIMARY KEY
);
CREATE TABLE "user" (
	"id" bigserial PRIMARY KEY,
	"email" varchar NOT NULL CONSTRAINT "user_email_key" UNIQUE,
	"cognito_id" varchar,
	"first_name" varchar,
	"last_name" varchar,
	"birthday" date,
	"permissions" varchar,
	"status" user_status NOT NULL,
	"location" varchar,
	"created_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
	"updated_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE "sqids"."blocklist" (
	"str" text PRIMARY KEY
);
CREATE UNIQUE INDEX "artist_pkey" ON "artist" ("id");
CREATE INDEX "artist_release__release_id" ON "artist_release" ("release_id");
CREATE INDEX "collectible__release_id" ON "collectible" ("release_id");
CREATE INDEX "collectible__user_id_status" ON "collectible" ("user_id","status");
CREATE UNIQUE INDEX "collectible_pkey" ON "collectible" ("id");
CREATE UNIQUE INDEX "collectible_provenance_unique" ON "collectible_history" ("collectible_id","index");
CREATE INDEX "collectible_transaction__release_id_status" ON "collectible_transaction" ("release_id","payment_status");
CREATE UNIQUE INDEX "collectible_transaction_payment_id_key" ON "collectible_transaction" ("payment_id");
CREATE UNIQUE INDEX "collectible_transaction_pkey" ON "collectible_transaction" ("id");
CREATE INDEX "recording__release_id_type_index" ON "recording" ("release_id","type","index");
CREATE UNIQUE INDEX "recording_pkey" ON "recording" ("id");
CREATE UNIQUE INDEX "release_pkey" ON "release" ("id");
CREATE UNIQUE INDEX "schema_migrations_pkey" ON "schema_migrations" ("version");
CREATE UNIQUE INDEX "user_email_key" ON "user" ("email");
CREATE UNIQUE INDEX "user_pkey" ON "user" ("id");
CREATE UNIQUE INDEX "blocklist_pkey" ON "sqids"."blocklist" ("str");
ALTER TABLE "artist_recording" ADD CONSTRAINT "artist_recording_artist_id_fkey" FOREIGN KEY ("artist_id") REFERENCES "artist"("id");
ALTER TABLE "artist_recording" ADD CONSTRAINT "artist_recording_recording_id_fkey" FOREIGN KEY ("recording_id") REFERENCES "recording"("id");
ALTER TABLE "artist_release" ADD CONSTRAINT "artist_release_artist_id_fkey" FOREIGN KEY ("artist_id") REFERENCES "artist"("id");
ALTER TABLE "artist_release" ADD CONSTRAINT "artist_release_release_id_fkey" FOREIGN KEY ("release_id") REFERENCES "release"("id");
ALTER TABLE "collectible" ADD CONSTRAINT "collectible_release_id_fkey" FOREIGN KEY ("release_id") REFERENCES "release"("id");
ALTER TABLE "collectible" ADD CONSTRAINT "collectible_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "user"("id");
ALTER TABLE "collectible_history" ADD CONSTRAINT "collectible_history_collectible_id_fkey" FOREIGN KEY ("collectible_id") REFERENCES "collectible"("id");
ALTER TABLE "collectible_history" ADD CONSTRAINT "collectible_history_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "user"("id");
ALTER TABLE "collectible_transaction" ADD CONSTRAINT "collectible_transaction_release_id_fkey" FOREIGN KEY ("release_id") REFERENCES "release"("id");
ALTER TABLE "collectible_transaction" ADD CONSTRAINT "collectible_transaction_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "user"("id");
ALTER TABLE "collectible_transaction_collectible" ADD CONSTRAINT "collectible_transaction_collect_collectible_transaction_id_fkey" FOREIGN KEY ("collectible_transaction_id") REFERENCES "collectible_transaction"("id");
ALTER TABLE "collectible_transaction_collectible" ADD CONSTRAINT "collectible_transaction_collectible_collectible_id_fkey" FOREIGN KEY ("collectible_id") REFERENCES "collectible"("id");
ALTER TABLE "recording" ADD CONSTRAINT "recording_release_id_fkey" FOREIGN KEY ("release_id") REFERENCES "release"("id");